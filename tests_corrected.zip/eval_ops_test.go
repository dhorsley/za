package main

import (
    "math/big"
    "testing"
)

func TestSliceString(t *testing.T) {
    s := "hello"
    res := slice(s, 1, 4) // should be "ell"
    if res != "ell" {
        t.Fatalf(`slice("hello",1,4) expected "ell", got %q`, res)
    }
}

func TestSliceArrayTypes(t *testing.T) {
    bArr := []bool{true, false, true}
    outB := slice(bArr, 1, 3).([]bool)
    if len(outB) != 2 || !outB[0] || !outB[1] {
        t.Fatalf("slice([]bool) failed, got %v", outB)
    }

    bi1 := big.NewInt(1)
    bi2 := big.NewInt(2)
    arr := []*big.Int{bi1, bi2}
    outArr := slice(arr, 0, 1).([]*big.Int)
    if len(outArr) != 1 || outArr[0].Cmp(bi1) != 0 {
        t.Fatalf("slice([]*big.Int) failed, got %v", outArr)
    }
}
