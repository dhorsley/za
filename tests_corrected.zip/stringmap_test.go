package main

import (
    "testing"
)

func TestLmapBasicCRUD(t *testing.T) {
    lm := nlmcreate(0)

    // Initially, no key should exist
    if lm.lmexists("foo") {
        t.Fatalf("expected \"foo\" to not exist")
    }

    // lmget should return (0,false)
    if v, ok := lm.lmget("foo"); ok || v != 0 {
        t.Fatalf("expected lmget(\"foo\") to return (0,false), got (%v,%v)", v, ok)
    }

    // After setting, exists and get must reflect new value
    lm.lmset("foo", 42)
    if !lm.lmexists("foo") {
        t.Fatalf("expected \"foo\" to exist after lmset")
    }
    if v, ok := lm.lmget("foo"); !ok || v != 42 {
        t.Fatalf("expected lmget(\"foo\") to return (42,true), got (%v,%v)", v, ok)
    }

    // Overwrite the value
    lm.lmset("foo", 99)
    if v, ok := lm.lmget("foo"); !ok || v != 99 {
        t.Fatalf("expected lmget(\"foo\") to return (99,true), got (%v,%v)", v, ok)
    }

    // Deleting a non-existent key returns false
    if deleted := lm.lmdelete("bar"); deleted {
        t.Fatalf("expected lmdelete(\"bar\") to return false")
    }

    // Deleting existing key returns true, and key disappears
    if deleted := lm.lmdelete("foo"); !deleted {
        t.Fatalf("expected lmdelete(\"foo\") to return true")
    }
    if lm.lmexists("foo") {
        t.Fatalf("expected \"foo\" to not exist after deletion")
    }
}
