package main

import (
    "testing"
)

// Test nextToken for basic identifiers and numbers
func TestNextTokenIdentifiersAndNumbers(t *testing.T) {
    input := "foo 123 bar"
    var line int16 = 1
    pos := 0

    // First token: "foo"
    tok1 := nextToken(input, 0, &line, pos)
    if tok1.carton.tokText != "foo" {
        t.Fatalf("expected first token \"foo\", got %q", tok1.carton.tokText)
    }
    pos = int(tok1.tokPos)

    // Second: "123"
    tok2 := nextToken(input, 0, &line, pos)
    if tok2.carton.tokText != "123" {
        t.Fatalf("expected second token \"123\", got %q", tok2.carton.tokText)
    }
    pos = int(tok2.tokPos)

    // Third: "bar"
    tok3 := nextToken(input, 0, &line, pos)
    if tok3.carton.tokText != "bar" {
        t.Fatalf("expected third token \"bar\", got %q", tok3.carton.tokText)
    }
    pos = int(tok3.tokPos)

    // Fourth: EOF
    tok4 := nextToken(input, 0, &line, pos)
    if !tok4.eof {
        t.Fatalf("expected EOF token, got %+v", tok4)
    }
}

// Test that string literals are unescaped correctly
func TestNextTokenStringLiteral(t *testing.T) {
    input := "\"hello\\nworld\" 'simple'"
    var line int16 = 1
    pos := 0

    // Double‐quoted literal
    tok1 := nextToken(input, 0, &line, pos)
    expected := "hello\nworld"
    if tok1.carton.tokText != expected {
        t.Fatalf("expected string literal %q, got %q", expected, tok1.carton.tokText)
    }
    pos = int(tok1.tokPos)

    // Single‐quoted literal
    tok2 := nextToken(input, 0, &line, pos)
    expected2 := "simple"
    if tok2.carton.tokText != expected2 {
        t.Fatalf("expected string literal %q, got %q", expected2, tok2.carton.tokText)
    }
}
