package main

import (
    "testing"
)

func makeToken(typ int64, text string, pos int16) Token {
    return Token{tokType: typ, tokText: text, tokPos: pos}
}

func TestPhraseParseSimple(t *testing.T) {
    const (
        Identifier  = 1
        O_Semicolon = 3
    )
    p := new(leparser)
    fs := uint32(0)
    functionspaces = make(map[uint32][]Phrase)
    functionspaces[fs] = []Phrase{{}}

    tokens := []Token{ 
        makeToken(Identifier, "foo", 0), 
        makeToken(O_Semicolon, ";", 3),
    }
    p.tokens = tokens
    p.pos = 0

    phraseParse(fs, p)

    parsed := functionspaces[fs]
    if len(parsed) != 1 {
        t.Fatalf("expected 1 phrase, got %d", len(parsed))
    }
    ph := parsed[0]
    if len(ph.Tokens) != 1 {
        t.Fatalf("expected phrase.Tokens length=1, got %d", len(ph.Tokens))
    }
    if ph.Tokens[0].tokText != "foo" {
        t.Fatalf("expected token \"foo\", got %q", ph.Tokens[0].tokText)
    }
}
