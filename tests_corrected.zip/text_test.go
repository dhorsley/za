package main

import (
    "testing"
)

func TestSanitiseSimple(t *testing.T) {
    input := "abc { def } ghi"
    out := sanitise(input)
    if out != input {
        t.Fatalf("sanitise on %q expected %q, got %q", input, input, out)
    }
}

func TestLgrepInline(t *testing.T) {
    input := "apple\nbanana\ncherry\n"
    out := lgrep(input, "an")
    if out != "banana" {
        t.Fatalf("lgrep(%q, \"an\") expected \"banana\", got %q", input, out)
    }
}
