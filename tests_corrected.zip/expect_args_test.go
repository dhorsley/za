package main

import (
    "math/big"
    "testing"
)

func TestExpectArgsSuccess(t *testing.T) {
    // No args, no variants → should succeed
    ok, err := expect_args("foo", []any{}, 0)
    if !ok || err != nil {
        t.Fatalf("expect_args with no args/variants should succeed, got ok=%v err=%v", ok, err)
    }

    // Exactly match number=2, types: "number","number"
    args := []any{3, 4.5}
    ok, err = expect_args("add", args, 1, "2", "number", "number")
    if !ok || err != nil {
        t.Fatalf("expect_args should accept two numbers, got ok=%v err=%v", ok, err)
    }

    // Bignumber variant
    bigVal := big.NewInt(123)
    ok, err = expect_args("bigcalc", []any{bigVal}, 1, "1", "bignumber")
    if !ok || err != nil {
        t.Fatalf("expect_args should accept a *big.Int as bignumber, got ok=%v err=%v", ok, err)
    }

    // Variant with []any
    sliceArg := []any{1, "x", true}
    ok, err = expect_args("scan", []any{sliceArg}, 1, "1", "[]any")
    if !ok || err != nil {
        t.Fatalf("expect_args should accept a []any, got ok=%v err=%v", ok, err)
    }
}

func TestExpectArgsFailure(t *testing.T) {
    // Wrong count
    ok, err := expect_args("foo", []any{1}, 1, "2", "number", "number")
    if ok || err == nil {
        t.Fatalf("expect_args should fail on wrong arg count, got ok=%v err=%v", ok, err)
    }

    // Nil value inside args
    args := []any{nil}
    ok, err = expect_args("foo", args, 1, "1", "number")
    if ok || err == nil {
        t.Fatalf("expect_args should reject nil value, got ok=%v err=%v", ok, err)
    }

    // Type mismatch
    args2 := []any{1, "not a number"}
    ok, err = expect_args("foo", args2, 1, "2", "number", "number")
    if ok || err == nil {
        t.Fatalf("expect_args should reject wrong type, got ok=%v err=%v", ok, err)
    }
}
