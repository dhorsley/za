package main

import (
    "testing"
)

func TestNmapBasicCRUD(t *testing.T) {
    nm := nnmcreate(0)

    // Initially, no key should exist
    if nm.lmexists(7) {
        t.Fatalf("expected key 7 to not exist")
    }

    // lmget should return ("",false)
    if v, ok := nm.lmget(7); ok || v != "" {
        t.Fatalf("expected lmget(7) to return (\"\",false), got (%q,%v)", v, ok)
    }

    // After setting, exists and get must reflect new value
    nm.lmset(7, "seven")
    if !nm.lmexists(7) {
        t.Fatalf("expected key 7 to exist after lmset")
    }
    if v, ok := nm.lmget(7); !ok || v != "seven" {
        t.Fatalf("expected lmget(7) to return (\"seven\",true), got (%q,%v)", v, ok)
    }

    // Overwrite the value
    nm.lmset(7, "SEVEN")
    if v, ok := nm.lmget(7); !ok || v != "SEVEN" {
        t.Fatalf("expected lmget(7) to return (\"SEVEN\",true), got (%q,%v)", v, ok)
    }

    // Deleting a non-existent key returns false
    if deleted := nm.lmdelete(8); deleted {
        t.Fatalf("expected lmdelete(8) to return false")
    }

    // Deleting existing key returns true, and key disappears
    if deleted := nm.lmdelete(7); !deleted {
        t.Fatalf("expected lmdelete(7) to return true")
    }
    if nm.lmexists(7) {
        t.Fatalf("expected key 7 to not exist after deletion")
    }
}
